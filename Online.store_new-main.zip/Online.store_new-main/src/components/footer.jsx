import "./footer.css";

function Footer(){

    return(
        <div className="footer">
            <label>Organika Store, a really expensive Store</label>
        </div>
    );
}

export default Footer;