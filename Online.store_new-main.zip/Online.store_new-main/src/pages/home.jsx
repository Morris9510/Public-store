import "./home.css"

function Home(){
    return (
        <div className="home">
            <h1>Welcome!</h1>
            <img src="/images/ca.jpeg" alt=""></img>
        </div>
    );

}

export default Home;